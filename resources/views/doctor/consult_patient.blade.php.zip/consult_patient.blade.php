@extends('doctor.layouts.default')
@section('content')

<style>
    .banner {
  padding: 0;
  background-color: #52575c;
  color: white;
}

.banner-text {
  padding: 8px 20px;
  margin: 0;
}


#join-form {
  margin-top: 10px;
}

.tips {
  font-size: 12px;
  margin-bottom: 2px;
  color: gray;
}

.join-info-text {
  margin-bottom: 2px;
}

input {
  width: 100%;
  margin-bottom: 2px;
}

.player {
  width: 787px;
  height: 444px;
  margin:6px;
}

.player-name {
  margin: 8px 0;
}

#success-alert, #success-alert-with-token {
  display: none;
}

@media (max-width: 640px) {
  .player {
    width: 320px;
    height: 240px;
  }
}
</style>
<section class="content-wrapper"> 
            @include('doctor.partials.sidebar')


        <div class="side-wrapper">
            <div class="card wrapper-card">
             <div class="card-body">
                <div class="profilecard consultcard">
                    <div class="profilecardcontent">
                        <div class="form-group text-center profileset">
                            <label class="consultdesign">
                                <label for="photo-upload" class="custom-file-upload consultprofile">
                                    <div class="img-wrap img-upload">
                                        <img for="photo-upload" src="{{ url('public/doctor/images/'.isset($patient) ? $patient->image:'default.png') }}">
                                    </div>
                                    <!-- <div class="p-image"> <i class="fa fa-camera upload-button"></i>
                                    <input class="file-upload" id="photo-upload" type="file" name="image" accept="image/*">
                                </div> -->
                                </label>
                            </label>
                        </div>
                    </div>
                    <h5>{{ isset($patient) ? $patient->first_name:'' }} {{ isset($patient) ? $patient->last_name:'' }}</h5>
                    <span>_{{ isset($patient) ? $patient->first_name:'' }}_{{ isset($patient) ? $patient->last_name:'' }}_</span>
                     <button class="defaultbtn numberbtn">
                         <a class="defaultbtn" href="{{ url('doctor/chat/'.base64_encode($patient->id))}}">
                         <i class="flaticon-write"></i>Chat
                         </a>
                     </button>
                                
                    <!--<span>{{ isset($patient) ? $patient->age:'' }} Years Old</span>-->

                    <div class="consultsocialitem">
                        <ul>
                            <li>
                                <button class="defaultbtn numberbtn">
                                    <i class="flaticon-phone"></i> {{ isset($patient) ? $patient->phone:'' }}
                                </button>
                            </li>

                            <li>
                                <!--<button class="defaultbtn"  data-toggle="modal" data-target="#exampleModal">-->
                                <!--    <i class="flaticon-video-camera"></i> Video Call-->
                                <!--</button>-->
                                
                                <button class="defaultbtn numberbtn"  id="numberbtn">
                                 <i class="flaticon-video-camera"></i> Video Call
                                 <input id="patient_id" type="hidden" value="{{ $patient->id }}">
                                 <input id="appid" type="hidden">
                                 <input id="token" type="hidden" >
                                 <input id="channel" type="hidden">
                                 <input id="patient_name" type="hidden" value="{{ $patient->first_name.' '.$patient->last_name}}">
                                </button>
                            </li>

                            <li>
                                <a href="{{ url('doctor/prescribe') }}">
                                    <button class="defaultbtn">
                                        <i class="flaticon-prescription"></i> Prescribe
                                    </button>
                                </a>
                            </li>

                            <li>
                               <a href="{{ url('doctor/ordertest') }}">
                                <button class="defaultbtn">
                                    <i class="flaticon-blood-test"></i> Order Test
                                </button>
                               </a>
                            </li>
                        </ul>
                    </div>

                    <div class="tabitem">
                        <ul>
                            <li class="tabactive" id="patientinfo">
                                Patient Info
                            </li>
                            <li id="visit">
                                Reason For Visit
                            </li>
                            <li id="soap">
                                Soap
                            </li>
                            <li id="summary">
                                Patient Visit Summary
                            </li>
                        </ul>
                    </div>
                </div>
             </div>

                <div class="tabarea">

                    <div class="firsttabcontent">
                        <div class="card-body form-body">
                            <div class="row">
                                <div class="col-md-8 offset-md-2 text-center">
                                  <div class="patient-info">
                                        <h5>Personal Info</h5>
                                        <table class="table">
                                            <tr>
                                            <td class="text-left" style="border-top: 0;">Date Of Birth:</td>
                                            <td class="text-right" style="border-top: 0;">{{ isset($patient) ? $patient->dob:'' }} </td>
                                            </tr>
                                            <tr>
                                                <td class="text-left">Address:</td>
                                                <td class="text-right">{{ isset($patient) ? $patient->address:'' }}</td>
                                            </tr>
                                            <!--<tr>-->
                                            <!--    <td class="text-left">City:</td>-->
                                            <!--    <td class="text-right">Worcester</td>-->
                                            <!--</tr>-->
                                            <tr>
                                                <td class="text-left">Zip Code:</td>
                                                <td class="text-right">{{ isset($patient) ? $patient->postal_code:'' }}</td>
                                            </tr>
                                            <!--<tr>-->
                                            <!--    <td class="text-left">State:</td>-->
                                            <!--    <td class="text-right">Massachusetts</td>-->
                                            <!--</tr>-->
                                            <tr>
                                                <td class="text-left">Insurance Or Self-Pay:</td>
                                                <td class="text-right">Massachusetts</td>
                                            </tr>
                                    </table>
                                  </div>

                                    <div class="medical_history">
                                        <h5>Medical History</h5>
                                        <table class="table">
                                            <thead class="custom-thead-dark">
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Documents</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Drug or Food Allergy</td>
                                                    <td>Penicil Reaction</td>
                                                    <td class="text-center"><img src="{{ url('public/doctor/images/icons/eye.png') }}" alt=""></td>
                                                </tr>
                                                    <tr>
                                                        <td>Chronic Medical illnesses</td>
                                                        <td>--------------</td>
                                                        <td class="text-center"><img src="{{ url('public/doctor/images/icons/eye.png') }}" alt=""></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Previous hospitalization in past 3 months</td>
                                                        <td>Document #01: EMR, 01/00/20
                                                            Document #01: EMR, 01/00/20
                                                        </td>
                                                        <td class="text-center"><img src="{{ url('public/doctor/images/icons/eye.png') }}" alt=""></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Medication list</td>
                                                        <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Social history(alcohol, smoking)</td>
                                                        <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>History of violence or substance abuse</td>
                                                        <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Immunization (Flu vaccine or shingles vaccines)</td>
                                                        <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</td>
                                                        <td></td>
                                                    </tr>
                                            </tbody>
                                    </table>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="secondtabcontent">
                        <div class="card-body form-body">
                            <div class="row">
                                <div class="col-md-6 offset-md-3">
                                    <div class="visitImg">
                                        <h5>Uplaoded Image/Document</h5>
                                        <ul>
                                            <li>
                                                <img src="{{ url('public/doctor/images/faceinfection.jpg') }}" alt="">
                                                <span>
                                                    <img src="{{ url('public/doctor/images/focus.png') }}" alt="">
                                                </span>
                                            </li>

                                            <li>
                                                <img src="{{ url('public/doctor/images/faceinfection.jpg') }}" alt="">
                                                <span>
                                                    <img src="{{ url('public/doctor/images/focus.png') }}" alt="">
                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            
                                <form action="">
                                    <div class="visitform">
                                        <div class="smartnotes">
                                            <div class="turnon">
                                                <button type="button" class="editbtn turnonbtn" id="">
                                                    <i class="flaticon-mic"></i> <span> Turn On Smart Notes
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="chiefcomp">
                                            <div class="form-group">
                                                <label for="">Chief Complaint</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button type="button" class="btn editbtn">
                                                    send
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                           

                        </div>
                    </div>

                    <div class="thirdtabcontent">
                        <div class="card-body form-body">
                           
                                <form action="">
                                    <div class="visitform mt-0">
                                        <div class="smartnotes">
                                            <div class="turnon">
                                                <button type="button" class="editbtn turnonbtn start-record-btn" id="start-record-btn">
                                                    <i class="flaticon-mic"></i> <span> Turn On Smart Notes
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="chiefcomp">
                                            <div class="form-group">
                                                <label for="">Subjective</label>
                                                <textarea name="" id="note-textarea" rows="3" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>


                                    
                                     <div class="visitform mt-0">
                                        <div class="smartnotes">
                                            <div class="turnon"> 
                                                <button type="button" class="editbtn turnonbtn start-record-btn1" id="start-record-btn1">
                                                    <i class="flaticon-mic"></i> <span> Turn On Smart Notes
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="chiefcomp">
                                            <div class="form-group">
                                                <label for="">Objective</label>
                                                <textarea name="" id="note-textarea-obj" rows="3" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="row">
                                        <div class="col-md-6 offset-md-3">
                                            
                                            
                                            <!--<div class="form-group soap_group">-->
                                            <!--    <label for="">Objective</label>-->
                                            <!--    <textarea name="" id="" rows="3" class="form-control"></textarea>-->
                                            <!--</div>-->

                                            <div class="maritalstatus">
                                            <h6>Mental Status</h6>
                                             <div class="form-group soapradio">
                                                 <label class="paymentradio">alert oriented
                                                     <input type="radio" checked="checked" name="radio">
                                                     <span class="checkmark"></span>
                                                   </label>
                                                   <label class="paymentradio">confused disoriented
                                                     <input type="radio" name="radio">
                                                     <span class="checkmark"></span>
                                                   </label>
                                             </div>
                                            </div>

                                            <div class="maritalstatus">
                                                <h6>Vital Signs</h6>
                                                 <div class="form-group soapradio">
                                                     <label class="paymentradio">temparature blood Pressure
                                                         <input type="radio" checked="checked" name="radio">
                                                         <span class="checkmark"></span>
                                                       </label>
                                                       <label class="paymentradio">finger sticks if available
                                                         <input type="radio" name="radio">
                                                         <span class="checkmark"></span>
                                                       </label>
                                                 </div>
                                            </div>

                                            <div class="maritalstatus">
                                                <h6>Uplaoded Images Or Test Results (If Applicable) Physical Findings:</h6>
                                            </div>

                                            <div class="form-group">
                                                <h5 style="font-weight: 600;">Assessment</h5>
                                                <label for="">Description Of Patient Problem List</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Impression (Differential Diagnosis)</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Add Diagnosis</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Result</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Type Dx Code</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="maritalstatus">
                                                <h6 style="font-weight: 600;">Plan</h6>
                                                <label>Prescription Ordered</label>
                                                 <div class="form-group soapradio">
                                                     <label class="paymentradio">temparature blood Pressure
                                                         <input type="radio" checked="checked" name="radio">
                                                         <span class="checkmark"></span>
                                                       </label>
                                                       <label class="paymentradio">finger sticks if available
                                                         <input type="radio" name="radio">
                                                         <span class="checkmark"></span>
                                                       </label>
                                                 </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="">how many?</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group consultinput">
                                               <div class="row">
                                                   <div class="col-md-6">
                                                    <h6 style="font-weight: 600;">Monitoring Parameters</h6>

                                                        <label for="">Education</label>
                                                        <input type="text" class="form-control">
                                                   </div>

                                                   <div class="col-md-6">
                                                        <label for="">diet</label>
                                                        <input type="text" class="form-control">
                                                   </div>

                                                   <div class="col-md-6">
                                                        <label for="">exercise</label>
                                                        <input type="text" class="form-control">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="">medication use</label>
                                                        <input type="text" class="form-control">
                                                   </div>

                                                   <div class="col-md-6">
                                                        <label for="">symptoms</label>
                                                        <input type="text" class="form-control">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="">smokings/alcohol</label>
                                                        <input type="text" class="form-control">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="">activity level</label>
                                                        <input type="text" class="form-control">
                                                    </div>
                                               </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Follow up visit</label>
                                                <textarea name="" id="" rows="3" class="form-control"></textarea>
                                            </div>
                                            

                                            <div class="form-group">
                                                <button type="button" class="btn editbtn">
                                                    Submit Soap
                                                </button>
                                            </div>
                                           </div>
                                    </div>
                                   
                                </form>
                           

                        </div>
                    </div>


                    <div class="fourtabcontent">
                        <div class="card-body form-body">
                           
                                <form action="">
                                    <div class="visitform mt-0">
                                        <div class="smartnotes">
                                            <div class="turnon">
                                                <button type="button" class="editbtn turnonbtn">
                                                    <i class="flaticon-mic"></i> <span> Turn On Smart
                                                        Notes
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="chiefcomp">
                                            <div class="form-group">
                                                <label for="">Plan Of Care Summary</label>
                                                <input type="text" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 offset-md-3">
                                            <div class="form-group">
                                                <label for="">Medications</label>
                                                <input type="text" class="form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="">Lab Tests</label>
                                                <input type="text" class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <label for="">What To Monitor For At Home</label>
                                                <input type="text" class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <label for="">When To Seek Emergency Help</label>
                                                <input type="text" class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <label for="">Your Suggested Next Follow Up With PCP Or Telemedicine</label>
                                                <input type="text" class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <button type="button" class="btn editbtn">
                                                    Send Patient Name
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                        </div>
                    </div>

                </div>


            </div>


        </div>


    </section>


    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog video_dialogue" role="document">
      <div class="modal-content">
        <div class="video-body">
            <div class="container">
                <div class="videoprofile">
                    <div class="row align-items-center">
                        <div class="col-md-1">
                            <div class="videopic">
                                <img src="images/overview/profileone.jpeg" alt="">
                            </div>
                        </div>
                        <div class="col-md-10">
                            <h5>Devon Cooper</h5>
                        </div>
                    </div>
                </div>

                <div class="centerrating">
                    <div class="ratequality">
                        <p>Please rate the quality of the call</p>
                        <div class="rating">
                            <input type="radio" id="star1" name="rating" value="1" />
                            <label class="star" for="star1" title="Bad" aria-hidden="true"></label>
                            <input type="radio" id="star2" name="rating" value="2" />
                            <label class="star" for="star2" title="Good" aria-hidden="true"></label>
                            <input type="radio" id="star3" name="rating" value="3" />
                            <label class="star" for="star3" title="Very good" aria-hidden="true"></label>
                            <input type="radio" id="star4" name="rating" value="4" />
                            <label class="star" for="star4" title="Great" aria-hidden="true"></label>
                            <input type="radio" id="star5" name="rating" value="5" />
                            <label class="star" for="star5" title="Awesome" aria-hidden="true"></label>
                          </div>
                    </div>

                    <div class="accuracyrate">
                        <p>Please rate the accurancy of the data provided by Lauren Spencer</p>
                        <div class="rating">
                            <input type="radio" id="accuracy5" name="accuracy" value="5" />
                            <label class="star" for="accuracy5" title="Awesome" aria-hidden="true"></label>
                            <input type="radio" id="accuracy4" name="accuracy" value="4" />
                            <label class="star" for="accuracy4" title="Great" aria-hidden="true"></label>
                            <input type="radio" id="accuracy3" name="accuracy" value="3" />
                            <label class="star" for="accuracy3" title="Very good" aria-hidden="true"></label>
                            <input type="radio" id="accuracy2" name="accuracy" value="2" />
                            <label class="star" for="accuracy2" title="Good" aria-hidden="true"></label>
                            <input type="radio" id="accuracy1" name="accuracy" value="1" />
                            <label class="star" for="accuracy1" title="Bad" aria-hidden="true"></label>
                          </div>
                    </div>

                    <div class="form-group">
                        <button type="button" class="editbtn" data-dismiss="modal">
                            Send
                        </button>
                    </div>

                </div>

            </div>
        </div>
      </div>
    </div>
  </div>



    <!-- JS, Popper.js, and jQuery -->
    <script src="{{ url('public/doctor/js/jquery.min.js') }}"></script>
    <script src="{{ url('public/doctor/js/bootstrap.min.js') }}"></script>

    <script>
        $(document).ready(function(){
            $('.firsttabcontent').show();
            $('.secondtabcontent').hide();
            $('.thirdtabcontent').hide();
            $('.fourtabcontent').hide();
            $('#patientinfo').click(function(){
                $('.secondtabcontent').hide();
                $('.thirdtabcontent').hide();
                $('.fourtabcontent').hide();
                $('.firsttabcontent').show();
                $(this).addClass('tabactive').siblings().removeClass("tabactive");
            });
            $('#visit').click(function(){
                $('.firsttabcontent').hide();
                $('.thirdtabcontent').hide();
                $('.fourtabcontent').hide();
                $('.secondtabcontent').show();
                $(this).addClass('tabactive').siblings().removeClass("tabactive");
            });
            $('#soap').click(function(){
                $('.firsttabcontent').hide();
                $('.secondtabcontent').hide();
                $('.fourtabcontent').hide();
                $('.thirdtabcontent').show();
                $(this).addClass('tabactive').siblings().removeClass("tabactive");
            });
            $('#summary').click(function(){
                $('.firsttabcontent').hide();
                $('.secondtabcontent').hide();
                $('.thirdtabcontent').hide();
                $('.fourtabcontent').show();
                $(this).addClass('tabactive').siblings().removeClass("tabactive");
            })
        })
    </script>
    
    
    
    
    
    
    
<script>
try {
var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
var recognition = new SpeechRecognition();
}
catch(e) {
  console.error(e);
  $('.no-browser-support').show();
  $('.app').hide();
}


var noteTextarea = $('#note-textarea');
var instructions = $('#recording-instructions');
var notesList = $('ul#notes');

var noteContent = '';

// Get all notes from previous sessions and display them.
var notes = getAllNotes();
renderNotes(notes);



/*-----------------------------
      Voice Recognition 
------------------------------*/

// If false, the recording will stop after a few seconds of silence.
// When true, the silence period is longer (about 15 seconds),
// allowing us to keep recording even when the user pauses. 
recognition.continuous = true;

// This block is called every time the Speech APi captures a line. 
recognition.onresult = function(event) {

  // event is a SpeechRecognitionEvent object.
  // It holds all the lines we have captured so far. 
  // We only need the current one.
  var current = event.resultIndex;

  // Get a transcript of what was said.
  var transcript = event.results[current][0].transcript;

  

  // Add the current transcript to the contents of our Note.
  // There is a weird bug on mobile, where everything is repeated twice.
  // There is no official solution so far so we have to handle an edge case.
  var mobileRepeatBug = (current == 1 && transcript == event.results[0][0].transcript);

  if(!mobileRepeatBug) {
    noteContent += transcript;
    noteTextarea.val(noteContent);
  }
};







recognition.onstart = function() { 
  instructions.text('Voice recognition activated. Try speaking into the microphone.');
}

recognition.onspeechend = function() {
  instructions.text('You were quiet for a while so voice recognition turned itself off.');
}

recognition.onerror = function(event) {
  if(event.error == 'no-speech') {
    instructions.text('No speech was detected. Try again.');  
  };
}



/*-----------------------------
      App buttons and input 
------------------------------*/

$('.start-record-btn').on('click', function(e) {
    alert("as")
  if (noteContent.length) {
    noteContent += ' ';
  }
  recognition.start();
});




$('#pause-record-btn').on('click', function(e) {
  recognition.stop();
  instructions.text('Voice recognition paused.');
});

// Sync the text inside the text area with the noteContent variable.
noteTextarea.on('input', function() {
  noteContent = $(this).val();
})

$('#save-note-btn').on('click', function(e) {
  recognition.stop();

  if(!noteContent.length) {
    instructions.text('Could not save empty note. Please add a message to your note.');
  }
  else {
    // Save note to localStorage.
    // The key is the dateTime with seconds, the value is the content of the note.
    saveNote(new Date().toLocaleString(), noteContent);

    // Reset variables and update UI.
    noteContent = '';
    renderNotes(getAllNotes());
    noteTextarea.val('');
    instructions.text('Note saved successfully.');
  }
      
})


notesList.on('click', function(e) {
  e.preventDefault();
  var target = $(e.target);

  // Listen to the selected note.
  if(target.hasClass('listen-note')) {
    var content = target.closest('.note').find('.content').text();
    readOutLoud(content);
  }

  // Delete note.
  if(target.hasClass('delete-note')) {
    var dateTime = target.siblings('.date').text();  
    deleteNote(dateTime);
    target.closest('.note').remove();
  }
});



/*-----------------------------
      Speech Synthesis 
------------------------------*/

function readOutLoud(message) {
	var speech = new SpeechSynthesisUtterance();

  // Set the text and voice attributes.
	speech.text = message;
	speech.volume = 1;
	speech.rate = 1;
	speech.pitch = 1;
  
	window.speechSynthesis.speak(speech);
}



/*-----------------------------
      Helper Functions 
------------------------------*/

function renderNotes(notes) {
  var html = '';
  if(notes.length) {
    notes.forEach(function(note) {
      html+= `<li class="note">
        <p class="header">
          <span class="date">${note.date}</span>
          <a href="#" class="listen-note" title="Listen to Note">Listen to Note</a>
          <a href="#" class="delete-note" title="Delete">Delete</a>
        </p>
        <p class="content">${note.content}</p>
      </li>`;    
    });
  }
  else {
    html = '<li><p class="content">You don\'t have any notes yet.</p></li>';
  }
  notesList.html(html);
}


function saveNote(dateTime, content) {
  localStorage.setItem('note-' + dateTime, content);
}


function getAllNotes() {
  var notes = [];
  var key;
  for (var i = 0; i < localStorage.length; i++) {
    key = localStorage.key(i);
    console.log(i)
    console.log(key)

    if(key.substring(0,5) == 'note-') {
      notes.push({
        date: key.replace('note-',''),
        content: localStorage.getItem(localStorage.key(i))
      });
    } 
  }
  console.log(notes)
  return notes;
}


function deleteNote(dateTime) {
  localStorage.removeItem('note-' + dateTime); 
}
        </script>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <script>
try {
var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
var recognition = new SpeechRecognition();
}
catch(e) {
  console.error(e);
  $('.no-browser-support').show();
  $('.app').hide();
}


var noteTextarea1 = $('#note-textarea-obj');
//var instructions = $('#recording-instructions');
//var notesList = $('ul#notes');

var noteContent = '';

// Get all notes from previous sessions and display them.
var notes = getAllNotes();
renderNotes(notes);



/*-----------------------------
      Voice Recognition 
------------------------------*/

// If false, the recording will stop after a few seconds of silence.
// When true, the silence period is longer (about 15 seconds),
// allowing us to keep recording even when the user pauses. 
recognition.continuous = true;

// This block is called every time the Speech APi captures a line. 
recognition.onresult = function(event) {

  // event is a SpeechRecognitionEvent object.
  // It holds all the lines we have captured so far. 
  // We only need the current one.
  var current = event.resultIndex;

  // Get a transcript of what was said.
  var transcript = event.results[current][0].transcript;

  

  // Add the current transcript to the contents of our Note.
  // There is a weird bug on mobile, where everything is repeated twice.
  // There is no official solution so far so we have to handle an edge case.
  var mobileRepeatBug = (current == 1 && transcript == event.results[0][0].transcript);

  if(!mobileRepeatBug) {
    noteContent += transcript;
    noteTextarea1.val(noteContent);
  }
};







recognition.onstart = function() { 
  instructions.text('Voice recognition activated. Try speaking into the microphone.');
}

recognition.onspeechend = function() {
  instructions.text('You were quiet for a while so voice recognition turned itself off.');
}

recognition.onerror = function(event) {
  if(event.error == 'no-speech') {
    instructions.text('No speech was detected. Try again.');  
  };
}



/*-----------------------------
      App buttons and input 
------------------------------*/

$('.start-record-btn1').on('click', function(e) {
     alert("aa")
  if (noteContent.length) {
    noteContent += ' ';
  }
  recognition.start();
});




$('#pause-record-btn').on('click', function(e) {
  recognition.stop();
  instructions.text('Voice recognition paused.');
});

// Sync the text inside the text area with the noteContent variable.
noteTextarea1.on('input', function() {
  noteContent = $(this).val();
})

$('#save-note-btn').on('click', function(e) {
  recognition.stop();

  if(!noteContent.length) {
    instructions.text('Could not save empty note. Please add a message to your note.');
  }
  else {
    // Save note to localStorage.
    // The key is the dateTime with seconds, the value is the content of the note.
    saveNote(new Date().toLocaleString(), noteContent);

    // Reset variables and update UI.
    noteContent = '';
    renderNotes(getAllNotes());
    noteTextarea1.val('');
    instructions.text('Note saved successfully.');
  }
      
})


notesList.on('click', function(e) {
  e.preventDefault();
  var target = $(e.target);

  // Listen to the selected note.
  if(target.hasClass('listen-note')) {
    var content = target.closest('.note').find('.content').text();
    readOutLoud(content);
  }

  // Delete note.
  if(target.hasClass('delete-note')) {
    var dateTime = target.siblings('.date').text();  
    deleteNote(dateTime);
    target.closest('.note').remove();
  }
});



/*-----------------------------
      Speech Synthesis 
------------------------------*/

function readOutLoud(message) {
	var speech = new SpeechSynthesisUtterance();

  // Set the text and voice attributes.
	speech.text = message;
	speech.volume = 1;
	speech.rate = 1;
	speech.pitch = 1;
  
	window.speechSynthesis.speak(speech);
}



/*-----------------------------
      Helper Functions 
------------------------------*/

function renderNotes(notes) {
  var html = '';
  if(notes.length) {
    notes.forEach(function(note) {
      html+= `<li class="note">
        <p class="header">
          <span class="date">${note.date}</span>
          <a href="#" class="listen-note" title="Listen to Note">Listen to Note</a>
          <a href="#" class="delete-note" title="Delete">Delete</a>
        </p>
        <p class="content">${note.content}</p>
      </li>`;    
    });
  }
  else {
    html = '<li><p class="content">You don\'t have any notes yet.</p></li>';
  }
  notesList.html(html);
}


function saveNote(dateTime, content) {
  localStorage.setItem('note-' + dateTime, content);
}


function getAllNotes() {
  var notes = [];
  var key;
  for (var i = 0; i < localStorage.length; i++) {
    key = localStorage.key(i);
    console.log(i)
    console.log(key)

    if(key.substring(0,5) == 'note-') {
      notes.push({
        date: key.replace('note-',''),
        content: localStorage.getItem(localStorage.key(i))
      });
    } 
  }
  console.log(notes)
  return notes;
}


function deleteNote(dateTime) {
  localStorage.removeItem('note-' + dateTime); 
}
        </script>


@endsection